package com.example.vaccarello_mattia_gitter_writer;

public class Lingua {
    String lingua;
    int Image;

    public Lingua(String lingua, int Image) {
        this.lingua = lingua;
        this.Image = Image;
    }
    public String getLingua() {
        return lingua;
    }

    public void setLingua(String lingua) {
        this.lingua = lingua;
    }

    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }

}

